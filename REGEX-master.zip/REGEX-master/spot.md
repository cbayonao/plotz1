Dicen que cuando tienes un problema y lo intentas solucionar con Expresiones regulares tienes dos problemas.

Falso.

Aunque las expresiones regulares pueden ser un poco intimidantes en un principio, son un herramienta que todo desarrollador –independientemente del lenguaje de programación de su preferencia– debe de traer SIEMPRE en la mochila.

Las expresiones regulares, fuera de las definiciones teóricas, se basan en un lenguaje aunque ha evolucionado desde hace más de medio siglo, sigue siendo el mismo desde los 80 Y TODO EL MUNDO LOS USA.

Sirven para crear patrones de búsqueda de texto y las herramientas (y lenguajes) que las utilizan se usan para tratar desde grandes volúmenes de datos hasta corroborar que una dirección de email está bien escrita.

Tratar, por ejemplo un archivo de más de 2 millones de líneas y 120 megas en menos de 2 segundos, nada mal, ¿no crees?

No sólo es copiar y pegar lo que parecen ser puntos, líneas, asteriscos, signos de interrogación que parecen tener ningún sentido de stack overflow, sino entender exactamente qué hace cada uno y crear los tuyos.
